﻿namespace Sky
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSend = new System.Windows.Forms.Button();
            this.tbChat = new System.Windows.Forms.RichTextBox();
            this.pnlControl = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCommands = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.tbChatpage = new System.Windows.Forms.RichTextBox();
            this.lstCommands = new System.Windows.Forms.ListBox();
            this.tmrSpeaking = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.pnlControl.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbChat);
            this.panel1.Controls.Add(this.btnSend);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 403);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 50);
            this.panel1.TabIndex = 0;
            // 
            // btnSend
            // 
            this.btnSend.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend.Location = new System.Drawing.Point(702, 0);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(80, 50);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click_1);
            // 
            // tbChat
            // 
            this.tbChat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbChat.Location = new System.Drawing.Point(0, 0);
            this.tbChat.Name = "tbChat";
            this.tbChat.Size = new System.Drawing.Size(702, 50);
            this.tbChat.TabIndex = 1;
            this.tbChat.Text = "";
            // 
            // pnlControl
            // 
            this.pnlControl.Controls.Add(this.lstCommands);
            this.pnlControl.Controls.Add(this.panel2);
            this.pnlControl.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlControl.Location = new System.Drawing.Point(422, 0);
            this.pnlControl.Name = "pnlControl";
            this.pnlControl.Size = new System.Drawing.Size(360, 403);
            this.pnlControl.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnSettings);
            this.panel2.Controls.Add(this.btnCommands);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(60, 403);
            this.panel2.TabIndex = 0;
            // 
            // btnCommands
            // 
            this.btnCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCommands.Location = new System.Drawing.Point(0, 0);
            this.btnCommands.Name = "btnCommands";
            this.btnCommands.Size = new System.Drawing.Size(60, 60);
            this.btnCommands.TabIndex = 1;
            this.btnCommands.Text = "Commands";
            this.btnCommands.UseVisualStyleBackColor = true;
            // 
            // btnSettings
            // 
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.Location = new System.Drawing.Point(0, 60);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(60, 60);
            this.btnSettings.TabIndex = 2;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            // 
            // tbChatpage
            // 
            this.tbChatpage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbChatpage.Location = new System.Drawing.Point(0, 0);
            this.tbChatpage.Name = "tbChatpage";
            this.tbChatpage.Size = new System.Drawing.Size(422, 403);
            this.tbChatpage.TabIndex = 2;
            this.tbChatpage.Text = "";
            // 
            // lstCommands
            // 
            this.lstCommands.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstCommands.FormattingEnabled = true;
            this.lstCommands.ItemHeight = 16;
            this.lstCommands.Location = new System.Drawing.Point(60, 0);
            this.lstCommands.Name = "lstCommands";
            this.lstCommands.Size = new System.Drawing.Size(300, 403);
            this.lstCommands.TabIndex = 1;
            // 
            // tmrSpeaking
            // 
            this.tmrSpeaking.Interval = 1000;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 453);
            this.Controls.Add(this.tbChatpage);
            this.Controls.Add(this.pnlControl);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.pnlControl.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox tbChat;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Panel pnlControl;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnCommands;
        private System.Windows.Forms.RichTextBox tbChatpage;
        private System.Windows.Forms.ListBox lstCommands;
        private System.Windows.Forms.Timer tmrSpeaking;
    }
}

