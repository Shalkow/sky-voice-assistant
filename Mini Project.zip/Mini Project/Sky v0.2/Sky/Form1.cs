﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AIMLbot;

using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.IO;

namespace Sky
{
    public partial class Form1 : Form
    {
        private String user = "Bob";
        ChatBot c = new ChatBot();
        

        public Form1()
        {
            InitializeComponent();
            tbChat.Focus();
            c.Chat();
            
        }



        private void btnSend_Click(object sender, EventArgs e)
        {
            working();
 
        }

        private void working()
        {
            if (tbChat.Text.Trim() != "")
            {
                chatPage.Text += user + ": " + tbChat.Text;
                String input = tbChat.Text;

                String output = c.getOutput(input);
                if (output != null)
                {
                    chatPage.Text += "\nSky: " + output;
                }
                else
                {
                    chatPage.Text = "Couldnt understand";
                }
                chatPage.Text += "\n\n";
                tbChat.Text = "";
            }
        }

        public class ChatBot
        {

            const string UserId = "Meph";
            private Bot AimlBot;
            private User myUser;

            public void Chat()
            {
                AimlBot = new Bot();
                myUser = new User(UserId, AimlBot);
                Initialize();
            }

            // Loads all the AIML files in the \AIML folder         
            public void Initialize()
            {
                AimlBot.loadSettings();
                AimlBot.isAcceptingUserInput = false;
                AimlBot.loadAIMLFromFiles();
                AimlBot.isAcceptingUserInput = true;
            }

            // Given an input string, finds a response using AIMLbot lib
            public String getOutput(String input)
            {
                Request r = new Request(input, myUser, AimlBot);
                Result res = AimlBot.Chat(r);
                return (res.Output);
            }
        }

        

        private void btnCommands_Click(object sender, EventArgs e)
        {
            if (lstCommands.Visible == false)
            {
                lstCommands.Visible = true;
            }
            else if (lstCommands.Visible == true)
            {
                lstCommands.Visible = false;
            }
        }

        private void btnListen_Click(object sender, EventArgs e)
        {
            



        }


        //--------------------------------------------------------------------------------------------------
        SpeechRecognitionEngine _recogniser = new SpeechRecognitionEngine();
        SpeechSynthesizer Sky = new SpeechSynthesizer();
        SpeechRecognitionEngine startListening = new SpeechRecognitionEngine();
        Random rnd = new Random();
        int RecTimeout = 0;
        DateTime timeNow = DateTime.Now;

        private void Form1_Load(object sender, EventArgs e)
        {
            _recogniser.SetInputToDefaultAudioDevice();
            _recogniser.LoadGrammarAsync(new Grammar(new GrammarBuilder(new Choices(File.ReadAllLines(@"DefaultCommands.txt")))));
            _recogniser.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(Default_SpeechRecognized);
            _recogniser.SpeechDetected += new EventHandler<SpeechDetectedEventArgs>(_recogniser_SpeechRecognised);
            _recogniser.RecognizeAsync(RecognizeMode.Multiple);

            startListening.SetInputToDefaultAudioDevice();
            startListening.LoadGrammarAsync(new Grammar(new GrammarBuilder(new Choices(File.ReadAllLines(@"DefaultCommands.txt")))));
            startListening.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(startListening_SpeechRecognized);

        }

        private void Default_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            int ranNum;
            String speech = e.Result.Text;

            if (speech == "Hello")
            {
                Sky.SpeakAsync("Hello, I am here");
            }
            else if (speech == "How are you")
            {
                Sky.SpeakAsync("I am working normally");
            }
            else if (speech == "What time is it")
            {
                Sky.SpeakAsync(DateTime.Now.ToString("h mm tt"));
            }
            else if (speech == "stop talking")
            {
                Sky.SpeakAsyncCancelAll();
                Sky.SpeakAsync("Yes sir");
                ranNum = rnd.Next(1);
                if (ranNum == 1)
                {
                    Sky.SpeakAsync("Yes sir");
                }
            }
            else if (speech == "stop listening")
            {
                Sky.SpeakAsync("Yes");
                _recogniser.RecognizeAsyncCancel();
                startListening.RecognizeAsync(RecognizeMode.Multiple);
            }
            else if (speech == "show commands")
            {
                string[] commands = (File.ReadAllLines(@"DefaultCommands.txt"));
                lstCommands.Items.Clear();
                lstCommands.SelectionMode = SelectionMode.None;
                lstCommands.Visible = true;
                foreach (string command in commands)
                {
                    lstCommands.Items.Add(command);
                }
            }
            else if (speech == "hide commands")
            {
                lstCommands.Visible = false;
            }
            else
            {
                working();
            }
        }

        private void _recogniser_SpeechRecognised(object sender, SpeechDetectedEventArgs e)
        {
            RecTimeout = 0;
        }

        private void startListening_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            string speech = e.Result.Text;
            if (speech == "wake up")
            {
                startListening.RecognizeAsyncCancel();
                Sky.SpeakAsync("Yes, I am here");
                _recogniser.RecognizeAsync(RecognizeMode.Multiple);
            }
        }

        private void tmrSpeaking_Tick(object sender, EventArgs e)
        {
            if (RecTimeout == 10)
            {
                _recogniser.RecognizeAsyncCancel();
            }
            else if (RecTimeout == 11)
            {
                tmrSpeaking.Stop();
                startListening.RecognizeAsync(RecognizeMode.Multiple);
                RecTimeout = 0;
            }
        }

        private void chatPage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
