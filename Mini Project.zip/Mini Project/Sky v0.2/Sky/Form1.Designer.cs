﻿namespace Sky
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbChat = new System.Windows.Forms.RichTextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnListen = new System.Windows.Forms.Button();
            this.btnCommands = new System.Windows.Forms.Button();
            this.chatPage = new System.Windows.Forms.RichTextBox();
            this.lstCommands = new System.Windows.Forms.ListBox();
            this.tmrSpeaking = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbChat);
            this.panel1.Controls.Add(this.btnSend);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 399);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(812, 50);
            this.panel1.TabIndex = 2;
            // 
            // tbChat
            // 
            this.tbChat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbChat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbChat.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbChat.Location = new System.Drawing.Point(0, 0);
            this.tbChat.Name = "tbChat";
            this.tbChat.Size = new System.Drawing.Size(712, 50);
            this.tbChat.TabIndex = 1;
            this.tbChat.Text = "";
            // 
            // btnSend
            // 
            this.btnSend.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend.FlatAppearance.BorderSize = 0;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSend.Location = new System.Drawing.Point(712, 0);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(100, 50);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btnListen);
            this.panel2.Controls.Add(this.btnCommands);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(742, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(70, 399);
            this.panel2.TabIndex = 1;
            // 
            // btnListen
            // 
            this.btnListen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnListen.FlatAppearance.BorderSize = 0;
            this.btnListen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListen.Location = new System.Drawing.Point(0, 71);
            this.btnListen.Name = "btnListen";
            this.btnListen.Size = new System.Drawing.Size(70, 70);
            this.btnListen.TabIndex = 3;
            this.btnListen.Text = "Listen";
            this.btnListen.UseVisualStyleBackColor = false;
            this.btnListen.Click += new System.EventHandler(this.btnListen_Click);
            // 
            // btnCommands
            // 
            this.btnCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCommands.FlatAppearance.BorderSize = 0;
            this.btnCommands.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCommands.Location = new System.Drawing.Point(0, 1);
            this.btnCommands.Name = "btnCommands";
            this.btnCommands.Size = new System.Drawing.Size(70, 70);
            this.btnCommands.TabIndex = 1;
            this.btnCommands.Text = "Commands";
            this.btnCommands.UseVisualStyleBackColor = false;
            this.btnCommands.Click += new System.EventHandler(this.btnCommands_Click);
            // 
            // chatPage
            // 
            this.chatPage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chatPage.Dock = System.Windows.Forms.DockStyle.Left;
            this.chatPage.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chatPage.Location = new System.Drawing.Point(0, 0);
            this.chatPage.Name = "chatPage";
            this.chatPage.ReadOnly = true;
            this.chatPage.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.chatPage.Size = new System.Drawing.Size(682, 399);
            this.chatPage.TabIndex = 4;
            this.chatPage.Text = "";
            this.chatPage.TextChanged += new System.EventHandler(this.chatPage_TextChanged);
            // 
            // lstCommands
            // 
            this.lstCommands.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lstCommands.Dock = System.Windows.Forms.DockStyle.Right;
            this.lstCommands.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lstCommands.FormattingEnabled = true;
            this.lstCommands.ItemHeight = 16;
            this.lstCommands.Location = new System.Drawing.Point(442, 0);
            this.lstCommands.Name = "lstCommands";
            this.lstCommands.Size = new System.Drawing.Size(300, 399);
            this.lstCommands.TabIndex = 5;
            this.lstCommands.Visible = false;
            // 
            // tmrSpeaking
            // 
            this.tmrSpeaking.Interval = 1000;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 449);
            this.Controls.Add(this.lstCommands);
            this.Controls.Add(this.chatPage);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox tbChat;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox chatPage;
        private System.Windows.Forms.Button btnCommands;
        private System.Windows.Forms.Button btnListen;
        private System.Windows.Forms.ListBox lstCommands;
        private System.Windows.Forms.Timer tmrSpeaking;
    }
}

