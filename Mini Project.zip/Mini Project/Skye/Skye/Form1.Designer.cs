﻿namespace Skye
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbChatBox = new System.Windows.Forms.RichTextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.pnlControl = new System.Windows.Forms.Panel();
            this.tbCommands = new System.Windows.Forms.RichTextBox();
            this.pnl1 = new System.Windows.Forms.Panel();
            this.btnCommands = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.pnlControl.SuspendLayout();
            this.pnl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbChatBox);
            this.panel1.Controls.Add(this.btnSend);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 403);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(782, 50);
            this.panel1.TabIndex = 0;
            // 
            // tbChatBox
            // 
            this.tbChatBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbChatBox.Location = new System.Drawing.Point(0, 0);
            this.tbChatBox.Name = "tbChatBox";
            this.tbChatBox.Size = new System.Drawing.Size(682, 50);
            this.tbChatBox.TabIndex = 1;
            this.tbChatBox.Text = "";
            // 
            // btnSend
            // 
            this.btnSend.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSend.Location = new System.Drawing.Point(682, 0);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(100, 50);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            // 
            // pnlControl
            // 
            this.pnlControl.Controls.Add(this.tbCommands);
            this.pnlControl.Controls.Add(this.pnl1);
            this.pnlControl.Controls.Add(this.richTextBox2);
            this.pnlControl.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlControl.Location = new System.Drawing.Point(327, 0);
            this.pnlControl.Name = "pnlControl";
            this.pnlControl.Size = new System.Drawing.Size(455, 403);
            this.pnlControl.TabIndex = 1;
            // 
            // tbCommands
            // 
            this.tbCommands.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbCommands.Location = new System.Drawing.Point(60, 0);
            this.tbCommands.Name = "tbCommands";
            this.tbCommands.ReadOnly = true;
            this.tbCommands.Size = new System.Drawing.Size(395, 403);
            this.tbCommands.TabIndex = 4;
            this.tbCommands.Text = "";
            // 
            // pnl1
            // 
            this.pnl1.Controls.Add(this.btnCommands);
            this.pnl1.Controls.Add(this.btnSettings);
            this.pnl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl1.Location = new System.Drawing.Point(0, 0);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(60, 403);
            this.pnl1.TabIndex = 3;
            // 
            // btnCommands
            // 
            this.btnCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCommands.Location = new System.Drawing.Point(0, 60);
            this.btnCommands.Name = "btnCommands";
            this.btnCommands.Size = new System.Drawing.Size(60, 60);
            this.btnCommands.TabIndex = 1;
            this.btnCommands.Text = "Commands";
            this.btnCommands.UseVisualStyleBackColor = true;
            this.btnCommands.Click += new System.EventHandler(this.btnCommands_Click);
            // 
            // btnSettings
            // 
            this.btnSettings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSettings.Location = new System.Drawing.Point(0, 0);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(60, 60);
            this.btnSettings.TabIndex = 0;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(-319, 1);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(319, 395);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(327, 403);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 453);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pnlControl);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.pnlControl.ResumeLayout(false);
            this.pnl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private RichTextBox tbChatBox;
        private Button btnSend;
        private Panel pnlControl;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox1;
        private RichTextBox tbCommands;
        private Panel pnl1;
        private Button btnCommands;
        private Button btnSettings;
    }
}