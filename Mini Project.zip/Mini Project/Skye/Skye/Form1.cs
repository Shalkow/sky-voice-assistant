namespace Skye
{
    public partial class Form1 : Form
    {
        bool pnlControlOpened=false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pnlControl.Width = 60;

        }

        private void btnCommands_Click(object sender, EventArgs e)
        {
            if(pnlControlOpened==false)
            {
                pnlControlOpened = true;
                pnlControl.Width = 360;

            }
            else
            {
                pnlControlOpened = false;
                pnlControl.Width = 60;
            }
        }
    }
}